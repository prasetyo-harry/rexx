<!DOCTYPE html>
<html>
<head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<style>
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover:not(.active) {
  background-color: #111;
}

.active {
  background-color: #04AA6D;
}
        .box {
            width: 100%;
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-top: 20px;
        }
</style>
</head>
<body>
<?php include('rexx.php'); ?>
    <div class="container box">
	<div>&nbsp;</div>
	<div>&nbsp;</div>
    <h4><b>Version Comparison</b></h4>

<?php

class Conversion { 

	function localzone($version){		
		 $event_date = date("Y-m-d H:i:s");
		if ($version < '1.0.17+60') {
			$tz = new DateTimeZone('Europe/Berlin');
			$date = new DateTime($event_date);
			$date->setTimezone($tz);
			echo $date->format('Y-m-d H:i:s')." (Berlin)";
		} else if ($version > '1.0.17+60'){
			$tz = new DateTimeZone('UTC');
			$date = new DateTime($event_date);
			$date->setTimezone($tz);
			echo $date->format('Y-m-d H:i:s')." (UTC)";
		} else {
			$tz = new DateTimeZone('Asia/Jakarta');
			$date = new DateTime($event_date);
			$date->setTimezone($tz);
			echo $date->format('Y-m-d H:i:s')." (Jakarta)";
		}
	}
}


$evtz = new Conversion;
echo $evtz->localzone('1.0.17+59')."<br>";
echo $evtz->localzone('1.0.17+61')."<br>";
echo $evtz->localzone('1.0.17+60')."<br>";
?>
    </div>
</body>
</html>