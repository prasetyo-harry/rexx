<!DOCTYPE html>
<html>
  
<head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <style>
	ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover:not(.active) {
  background-color: #111;
}

.active {
  background-color: #04AA6D;
}
        .box {
            width: 100%;
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-top: 20px;
        }
    </style>
</head>
  
<body>
<?php include('rexx.php'); ?>
    <div class="container box">
        <h3 align="center">
            JSON data imported into database
        </h3><br />
          
        <?php
          
            include('connection.php');
              
            $query = '';
            $table_data = '';
            
            $filename = "data.json";
            
            $data = file_get_contents($filename); 
            
            $array = json_decode($data, true); 
            
            foreach($array as $row) {
  
                $query .= 
                "INSERT INTO participation VALUES 
                ('".$row["participation_id"]."', '".$row["employee_name"]."', '".$row["employee_mail"]."', '".$row["event_id"]."', 
                '".$row["event_name"]."' , '".$row["participation_fee"]."', '".$row["event_date"]."', '".$row["version"]."'); "; 
               
                $table_data .= '
                <tr>
                    <td>'.$row["participation_id"].'</td>
                    <td>'.$row["employee_name"].'</td>
                    <td>'.$row["employee_mail"].'</td>
                    <td>'.$row["event_id"].'</td>
                    <td>'.$row["event_name"].'</td>
                    <td>'.$row["participation_fee"].'</td>
                    <td>'.$row["event_date"].'</td>	
                    <td>'.$row["version"].'</td>						
                </tr>
                '; // Data for display on Web page
            }
  
            if(mysqli_multi_query($connect, $query)) {
                echo '<h3>Inserted JSON Data</h3><br />';
                echo '
                <table class="table table-bordered">
                <tr>
                    <th width="10%">Participation ID</th>
                    <th width="50%">Employee Name</th>
                    <th width="30%">Employee Mail</th>
					<th width="10%">Event ID</th>
					<th width="50%">Event Name</th>
					<th width="40%">Participation Fee</th>
					<th width="20%">Even Date</th>
					<th width="20%">Version</th>
                </tr>
                ';
                echo $table_data;  
                echo '</table>';
            }
          ?>
        <br />
    </div>
</body>
  
</html>