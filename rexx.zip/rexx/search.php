	<div>
		<form method="POST" action="res_courses.php" name="searchCourses">
			<tr>
				<td>Employee Name :</td>
				<td>
					<select name="empName">
						<option value="">Please Select</option>
						<?php
						include ('connection.php');
						$sqlEmpName = "SELECT DISTINCT(employee_name) FROM participation ORDER BY employee_name ASC";
						$qEmpName = mysqli_query($connect, $sqlEmpName);
						while ($resEmpName = mysqli_fetch_array($qEmpName) ) {
							echo "<option value=\"$resEmpName[employee_name]\">$resEmpName[employee_name]</option>";
						}
						?>
					</select>
				</td>
				<td>Event Name :</td>
				<td>
					<select name="evName">
						<option value="">Please Select</option>
						<?php
						include ('connection.php');
						$sqlEvName = "SELECT DISTINCT(event_name) FROM participation ORDER BY event_name ASC";
						$qEvName = mysqli_query($connect, $sqlEvName);
						while ($resEvName = mysqli_fetch_array($qEvName) ) {
							echo "<option value=\"$resEvName[event_name]\">$resEvName[event_name]</option>";
						}
						?>
					</select>
				</td>
				<td>Event Date :</td>
				<td><input type="date" name="evDate"></td>
				<td><input type="submit" name="find" value="Find"></td>
			</tr>
		</form>
	</div>