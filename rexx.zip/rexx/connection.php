<?php

$databaseHost = 'localhost';
$databaseName = 'coursedb';
$databaseUsername = 'root';
$databasePassword = '';

$connect = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); 
	
?>
