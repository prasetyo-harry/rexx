<!DOCTYPE html>
<html>
  
<head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  
    <style>
		ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover:not(.active) {
  background-color: #111;
}
        .box {
            width: 100%;
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-top: 20px;
        }
    </style>
</head>
  
<body>
<?php include('rexx.php'); ?>
    <div class="container box">
<?php

$empName	= $_POST['empName'];
$evName		= $_POST['evName'];
$evDates	= $_POST['evDate'];
$evDate		= date("Y-m-d", strtotime($evDates));


if($evDate == '1970-01-01'){
	$evDate = '';
}

include('connection.php');


if ($empName=='' AND $evName=='' AND $evDate==''){
	echo "<h2 style=\"color:red\"><center>None of the categories selected</center></h2>";
}

/****** CASE1 ****/
if ($empName !=='' AND $evName =='' AND $evDate ==''){
	$qempName = "SELECT * FROM participation WHERE employee_name LIKE '%$empName%'";
	$NmempName = mysqli_query($connect, $qempName);
	$links = mysqli_num_rows($NmempName);

if ($links==0){
	echo "<h2 style=\"color:red\"><center>Employee Name Not Found</center></h2>";
}else if($links>0){
		
		include('search.php');
		echo "<div>&nbsp;</div>";
		echo"<div style=\"font-weight:bold;\ align=\"center\">Employee Name Search Result</div>";
		echo "<table class=\"table table-bordered\">";
  		echo "<tr>";
		echo "<td><b>Participation ID</b></td>";
		echo "<td><b>Employee Name</b></td>";
		echo "<td><b>Employee Mail</b></td>";
		echo "<td><b>Event ID</b></td>";
		echo "<td><b>Event Name</b></td>";
		echo "<td><b>Participation Fee</b></td>";
		echo "<td><b>Event Date</b></td>";
		echo "<td><b>Version</b></td>";
  		echo "</tr>";
		while($list = mysqli_fetch_array($NmempName)){
			$participation_id=$list['participation_id'];
			$employee_name=$list['employee_name'];
			$employee_mail=$list['employee_mail'];
			$event_id=$list['event_id'];
			$event_name=$list['event_name'];
			$participation_fee=$list['participation_fee'];
			$event_date=$list['event_date'];
			$version=$list['version'];

		
			echo "<tr>";
			echo "<td>$participation_id</td>";
			echo "<td>$employee_name</td>";
			echo "<td>$employee_mail</td>";
			echo "<td>$event_id</td>";
			echo "<td>$event_name</td>";
			echo "<td><div style=\"float:right;\">$participation_fee</div></td>";
			echo "<td>";
			if ($version < '1.0.17+60') {
				$tz = new DateTimeZone('Europe/Berlin');
				$date = new DateTime($event_date);
				$date->setTimezone($tz);
				echo $date->format('Y-m-d H:i:s')." (Berlin)";
			} else if ($version > '1.0.17+60'){
				$tz = new DateTimeZone('UTC');
				$date = new DateTime($event_date);
				$date->setTimezone($tz);
				echo $event_date." (Berlin)"." / ".$date->format('Y-m-d H:i:s')." (UTC)";
			} else {
				$tz = new DateTimeZone('Asia/Jakarta');
				$date = new DateTime($event_date);
				$date->setTimezone($tz);
				echo $date->format('Y-m-d H:i:s')." (Jakarta)";
			}
			echo "</td>";
			echo "<td>$version</td>";
			echo "</tr>";
			
		}
			$totEmpName = "SELECT ROUND(SUM(participation_fee),2) AS total FROM participation WHERE employee_name LIKE '%$empName%'";
			$totNmempName = mysqli_query($connect, $totEmpName);
			$row = mysqli_fetch_array($totNmempName);
			$sum = $row['total'];			
			echo "<tr>";
			echo "<td colspan=5>Total Fee</td>";
			echo "<td><div style=\"float:right;\">$sum</div></td>";
			echo "<td>&nbsp;</td>";
			echo "<td>&nbsp;</td>";
			echo "</tr>";
			
			echo "</table>";
	}
			
}

/*** CASE 2 *****/
if ($empName =='' AND $evName !=='' AND $evDate ==''){
	$qevName = "SELECT * FROM participation WHERE event_name LIKE '%$evName%'";
	$NmevName = mysqli_query($connect, $qevName);
	$links = mysqli_num_rows($NmevName);

if ($links==0){
	echo "<h2 style=\"color:red\"><center>Event Name Not Found</center></h2>";
}else if($links>0){
		//include('list_data.php');
		include('search.php');
		echo "<div>&nbsp;</div>";
		echo"<div style=\"font-weight:bold;\ align=\"center\">Event Name Search Result</div>";
		echo "<table class=\"table table-bordered\">";
  		echo "<tr>";
		echo "<td><b>Participation ID</b></td>";
		echo "<td><b>Employee Name</b></td>";
		echo "<td><b>Employee Mail</b></td>";
		echo "<td><b>Event ID</b></td>";
		echo "<td><b>Event Name</b></td>";
		echo "<td><b>Participation Fee</b></td>";
		echo "<td><b>Event Date</b></td>";
		echo "<td><b>Version</b></td>";
  		echo "</tr>";
		while($list = mysqli_fetch_array($NmevName)){
			$participation_id=$list['participation_id'];
			$employee_name=$list['employee_name'];
			$employee_mail=$list['employee_mail'];
			$event_id=$list['event_id'];
			$event_name=$list['event_name'];
			$participation_fee=$list['participation_fee'];
			$event_date=$list['event_date'];
			$version=$list['version'];
		
			echo "<tr>";
			echo "<td>$participation_id</td>";
			echo "<td>$employee_name</td>";
			echo "<td>$employee_mail</td>";
			echo "<td>$event_id</td>";
			echo "<td>$event_name</td>";
			echo "<td><div style=\"float:right;\">$participation_fee</div></td>";
			echo "<td>";
			if ($version < '1.0.17+60') {
				$tz = new DateTimeZone('Europe/Berlin');
				$date = new DateTime($event_date);
				$date->setTimezone($tz);
				echo $date->format('Y-m-d H:i:s')." (Berlin)";
			} else if ($version > '1.0.17+60'){
				$tz = new DateTimeZone('UTC');
				$date = new DateTime($event_date);
				$date->setTimezone($tz);
				echo $event_date." (Berlin)"." / ".$date->format('Y-m-d H:i:s')." (UTC)";
			} else {
				$tz = new DateTimeZone('Asia/Jakarta');
				$date = new DateTime($event_date);
				$date->setTimezone($tz);
				echo $date->format('Y-m-d H:i:s')." (Jakarta)";
			}
			echo "</td>";
			echo "<td>$version</td>";
			echo "</tr>";
		}
			$totEvName = "SELECT ROUND(SUM(participation_fee),2) AS total FROM participation WHERE event_name LIKE '%$evName%'";
			$totNmevpName = mysqli_query($connect, $totEvName);
			$row = mysqli_fetch_array($totNmevpName);
			$sum = $row['total'];			
			echo "<tr>";
			echo "<td colspan=5>Total Fee</td>";
			echo "<td><div style=\"float:right;\">$sum</div></td>";
			echo "<td>&nbsp;</td>";
			echo "<td>&nbsp;</td>";
			echo "</tr>";
			echo "</table>";
	}
			
}

/*** CASE 3 ****/
if ($empName =='' AND $evName =='' AND $evDate !==''){
	$qevDate = "SELECT * FROM participation WHERE event_date LIKE '%$evDate%'";
	$NmevDate = mysqli_query($connect, $qevDate);
	$links = mysqli_num_rows($NmevDate);

if ($links==0){
	echo "<h2 style=\"color:red\"><center>Event Date Not Found</center></h2>";
}else if($links>0){
		include('search.php');
		echo "<div>&nbsp;</div>";
		echo"<div style=\"font-weight:bold;\ align=\"center\">Event Date Search Result</div>";
		echo "<table class=\"table table-bordered\">";
  		echo "<tr>";
		echo "<td><b>Participation ID</b></td>";
		echo "<td><b>Employee Name</b></td>";
		echo "<td><b>Employee Mail</b></td>";
		echo "<td><b>Event ID</b></td>";
		echo "<td><b>Event Name</b></td>";
		echo "<td><b>Participation Fee</b></td>";
		echo "<td><b>Event Date</b></td>";
		echo "<td><b>Version</b></td>";
  		echo "</tr>";
		while($list = mysqli_fetch_array($NmevDate)){
			$participation_id=$list['participation_id'];
			$employee_name=$list['employee_name'];
			$employee_mail=$list['employee_mail'];
			$event_id=$list['event_id'];
			$event_name=$list['event_name'];
			$participation_fee=$list['participation_fee'];
			$event_date=$list['event_date'];
			$version=$list['version'];
		
			echo "<tr>";
			echo "<td>$participation_id</td>";
			echo "<td>$employee_name</td>";
			echo "<td>$employee_mail</td>";
			echo "<td>$event_id</td>";
			echo "<td>$event_name</td>";
			echo "<td><div style=\"float:right;\">$participation_fee</div></td>";
			echo "<td>";
			if ($version < '1.0.17+60') {
				$tz = new DateTimeZone('Europe/Berlin');
				$date = new DateTime($event_date);
				$date->setTimezone($tz);
				echo $date->format('Y-m-d H:i:s')." (Berlin)";
			} else if ($version > '1.0.17+60'){
				$tz = new DateTimeZone('UTC');
				$date = new DateTime($event_date);
				$date->setTimezone($tz);
				echo $event_date." (Berlin)"." / ".$date->format('Y-m-d H:i:s')." (UTC)";
			} else {
				$tz = new DateTimeZone('Asia/Jakarta');
				$date = new DateTime($event_date);
				$date->setTimezone($tz);
				echo $date->format('Y-m-d H:i:s')." (Jakarta)";
			}
			echo "</td>";
			echo "<td>$version</td>";
			echo "</tr>";
		}
			$totEvDate = "SELECT ROUND(SUM(participation_fee),2) AS total FROM participation WHERE event_date LIKE '%$evDate%'";
			$totNmevpDate = mysqli_query($connect, $totEvDate);
			$row = mysqli_fetch_array($totNmevpDate);
			$sum = $row['total'];			
			echo "<tr>";
			echo "<td colspan=5>Total Fee</td>";
			echo "<td><div style=\"float:right;\">$sum</div></td>";
			echo "<td>&nbsp;</td>";
			echo "<td>&nbsp;</td>";
			echo "</tr>";
			echo "</table>";
	}
			
}
/*** CASE 4 *******/
if ($empName !=='' AND $evName !=='' AND $evDate ==''){
	$q4 = "SELECT * FROM participation WHERE employee_name LIKE '%$empName%' AND event_name LIKE '%$evName%' ";
	$Nm4 = mysqli_query($connect, $q4);
	$links = mysqli_num_rows($Nm4);

if ($links==0){
	echo "<h2 style=\"color:red\"><center>Case 4 Not Found</center></h2>";
}else if($links>0){
		include('search.php');
		echo "<div>&nbsp;</div>";
		echo"<div style=\"font-weight:bold;\ align=\"center\">Case 4 Search Result</div>";
		echo "<table class=\"table table-bordered\">";
  		echo "<tr>";
		echo "<td><b>Participation ID</b></td>";
		echo "<td><b>Employee Name</b></td>";
		echo "<td><b>Employee Mail</b></td>";
		echo "<td><b>Event ID</b></td>";
		echo "<td><b>Event Name</b></td>";
		echo "<td><b>Participation Fee</b></td>";
		echo "<td><b>Event Date</b></td>";
		echo "<td><b>Version</b></td>";
  		echo "</tr>";
		while($list = mysqli_fetch_array($Nm4)){
			$participation_id=$list['participation_id'];
			$employee_name=$list['employee_name'];
			$employee_mail=$list['employee_mail'];
			$event_id=$list['event_id'];
			$event_name=$list['event_name'];
			$participation_fee=$list['participation_fee'];
			$event_date=$list['event_date'];
			$version=$list['version'];
		
			echo "<tr>";
			echo "<td>$participation_id</td>";
			echo "<td>$employee_name</td>";
			echo "<td>$employee_mail</td>";
			echo "<td>$event_id</td>";
			echo "<td>$event_name</td>";
			echo "<td><div style=\"float:right;\">$participation_fee</div></td>";
			echo "<td>";
			if ($version < '1.0.17+60') {
				$tz = new DateTimeZone('Europe/Berlin');
				$date = new DateTime($event_date);
				$date->setTimezone($tz);
				echo $date->format('Y-m-d H:i:s')." (Berlin)";
			} else if ($version > '1.0.17+60'){
				$tz = new DateTimeZone('UTC');
				$date = new DateTime($event_date);
				$date->setTimezone($tz);
				echo $event_date." (Berlin)"." / ".$date->format('Y-m-d H:i:s')." (UTC)";
			} else {
				$tz = new DateTimeZone('Asia/Jakarta');
				$date = new DateTime($event_date);
				$date->setTimezone($tz);
				echo $date->format('Y-m-d H:i:s')." (Jakarta)";
			}
			echo "</td>";
			echo "<td>$version</td>";
			echo "</tr>";
		}
			$totCase4 = "SELECT ROUND(SUM(participation_fee),2) AS total FROM participation WHERE employee_name LIKE '%$empName%' AND event_name LIKE '%$evName%'";
			$totNmCase4 = mysqli_query($connect, $totCase4);
			$row = mysqli_fetch_array($totNmCase4);
			$sum = $row['total'];			
			echo "<tr>";
			echo "<td colspan=5>Total Fee</td>";
			echo "<td><div style=\"float:right;\">$sum</div></td>";
			echo "<td>&nbsp;</td>";
			echo "<td>&nbsp;</td>";
			echo "</tr>";
			echo "</table>";
	}
			
}

/*** CASE 5 *******/
if ($empName !=='' AND $evName =='' AND $evDate !==''){
	$q5 = "SELECT * FROM participation WHERE employee_name LIKE '%$empName%' AND event_date LIKE '%$evDate%' ";
	$Nm5 = mysqli_query($connect, $q5);
	$links = mysqli_num_rows($Nm5);

if ($links==0){
	echo "<h2 style=\"color:red\"><center>Case 5 Not Found</center></h2>";
}else if($links>0){
		include('search.php');
		echo "<div>&nbsp;</div>";
		echo"<div style=\"font-weight:bold;\ align=\"center\">Case 5 Search Result</div>";
		echo "<table class=\"table table-bordered\">";
  		echo "<tr>";
		echo "<td><b>Participation ID</b></td>";
		echo "<td><b>Employee Name</b></td>";
		echo "<td><b>Employee Mail</b></td>";
		echo "<td><b>Event ID</b></td>";
		echo "<td><b>Event Name</b></td>";
		echo "<td><b>Participation Fee</b></td>";
		echo "<td><b>Event Date</b></td>";
		echo "<td><b>Version</b></td>";
  		echo "</tr>";
		while($list = mysqli_fetch_array($Nm5)){
			$participation_id=$list['participation_id'];
			$employee_name=$list['employee_name'];
			$employee_mail=$list['employee_mail'];
			$event_id=$list['event_id'];
			$event_name=$list['event_name'];
			$participation_fee=$list['participation_fee'];
			$event_date=$list['event_date'];
			$version=$list['version'];
		
			echo "<tr>";
			echo "<td>$participation_id</td>";
			echo "<td>$employee_name</td>";
			echo "<td>$employee_mail</td>";
			echo "<td>$event_id</td>";
			echo "<td>$event_name</td>";
			echo "<td><div style=\"float:right;\">$participation_fee</div></td>";
			echo "<td>";
			if ($version < '1.0.17+60') {
				$tz = new DateTimeZone('Europe/Berlin');
				$date = new DateTime($event_date);
				$date->setTimezone($tz);
				echo $date->format('Y-m-d H:i:s')." (Berlin)";
			} else if ($version > '1.0.17+60'){
				$tz = new DateTimeZone('UTC');
				$date = new DateTime($event_date);
				$date->setTimezone($tz);
				echo $event_date." (Berlin)"." / ".$date->format('Y-m-d H:i:s')." (UTC)";
			} else {
				$tz = new DateTimeZone('Asia/Jakarta');
				$date = new DateTime($event_date);
				$date->setTimezone($tz);
				echo $date->format('Y-m-d H:i:s')." (Jakarta)";
			}
			echo "</td>";
			echo "<td>$version</td>";
			echo "</tr>";
		}
			$totCase5 = "SELECT ROUND(SUM(participation_fee),2) AS total FROM participation WHERE employee_name LIKE '%$empName%' AND event_date LIKE '%$evDate%'";
			$totNmCase5 = mysqli_query($connect, $totCase5);
			$row = mysqli_fetch_array($totNmCase5);
			$sum = $row['total'];			
			echo "<tr>";
			echo "<td colspan=5>Total Fee</td>";
			echo "<td><div style=\"float:right;\">$sum</div></td>";
			echo "<td>&nbsp;</td>";
			echo "<td>&nbsp;</td>";
			echo "</tr>";
			echo "</table>";
	}
			
}

/*** CASE 6 *******/
if ($empName =='' AND $evName !=='' AND $evDate !==''){
	$q6 = "SELECT * FROM participation WHERE event_name LIKE '%$evName%' AND event_date LIKE '%$evDate%' ";
	$Nm6 = mysqli_query($connect, $q6);
	$links = mysqli_num_rows($Nm6);

if ($links==0){
	echo "<h2 style=\"color:red\"><center>Case 6 Not Found</center></h2>";
}else if($links>0){
		include('search.php');
		echo "<div>&nbsp;</div>";
		echo"<div style=\"font-weight:bold;\ align=\"center\">Case 6 Search Result</div>";
		echo "<table class=\"table table-bordered\">";
  		echo "<tr>";
		echo "<td><b>Participation ID</b></td>";
		echo "<td><b>Employee Name</b></td>";
		echo "<td><b>Employee Mail</b></td>";
		echo "<td><b>Event ID</b></td>";
		echo "<td><b>Event Name</b></td>";
		echo "<td><b>Participation Fee</b></td>";
		echo "<td><b>Event Date</b></td>";
		echo "<td><b>Version</b></td>";
  		echo "</tr>";
		while($list = mysqli_fetch_array($Nm6)){
			$participation_id=$list['participation_id'];
			$employee_name=$list['employee_name'];
			$employee_mail=$list['employee_mail'];
			$event_id=$list['event_id'];
			$event_name=$list['event_name'];
			$participation_fee=$list['participation_fee'];
			$event_date=$list['event_date'];
			$version=$list['version'];
		
			echo "<tr>";
			echo "<td>$participation_id</td>";
			echo "<td>$employee_name</td>";
			echo "<td>$employee_mail</td>";
			echo "<td>$event_id</td>";
			echo "<td>$event_name</td>";
			echo "<td><div style=\"float:right;\">$participation_fee</div></td>";
			echo "<td>";
			if ($version < '1.0.17+60') {
				$tz = new DateTimeZone('Europe/Berlin');
				$date = new DateTime($event_date);
				$date->setTimezone($tz);
				echo $date->format('Y-m-d H:i:s')." (Berlin)";
			} else if ($version > '1.0.17+60'){
				$tz = new DateTimeZone('UTC');
				$date = new DateTime($event_date);
				$date->setTimezone($tz);
				echo $event_date." (Berlin)"." / ".$date->format('Y-m-d H:i:s')." (UTC)";
			} else {
				$tz = new DateTimeZone('Asia/Jakarta');
				$date = new DateTime($event_date);
				$date->setTimezone($tz);
				echo $date->format('Y-m-d H:i:s')." (Jakarta)";
			}
			echo "</td>";
			echo "<td>$version</td>";
			echo "</tr>";
		}
			$totCase6 = "SELECT ROUND(SUM(participation_fee),2) AS total FROM participation WHERE event_name LIKE '%$evName%' AND event_date LIKE '%$evDate%'";
			$totNmCase6 = mysqli_query($connect, $totCase6);
			$row = mysqli_fetch_array($totNmCase6);
			$sum = $row['total'];			
			echo "<tr>";
			echo "<td colspan=5>Total Fee</td>";
			echo "<td><div style=\"float:right;\">$sum</div></td>";
			echo "<td>&nbsp;</td>";
			echo "<td>&nbsp;</td>";
			echo "</tr>";
			echo "</table>";
	}
			
}

/*** CASE 7 *******/
if ($empName !=='' AND $evName !=='' AND $evDate !==''){
	$q7 = "SELECT * FROM participation WHERE employee_name LIKE '%$empName%' AND event_name LIKE '%$evName%' AND event_date LIKE '%$evDate%' ";
	$Nm7 = mysqli_query($connect, $q7);
	$links = mysqli_num_rows($Nm7);

if ($links==0){
	echo "<h2 style=\"color:red\"><center>Case 7 Not Found</center></h2>";
}else if($links>0){
		include('search.php');
		echo "<div>&nbsp;</div>";
		echo"<div style=\"font-weight:bold;\ align=\"center\">Case 7 Search Result</div>";
		echo "<table class=\"table table-bordered\">";
  		echo "<tr>";
		echo "<td><b>Participation ID</b></td>";
		echo "<td><b>Employee Name</b></td>";
		echo "<td><b>Employee Mail</b></td>";
		echo "<td><b>Event ID</b></td>";
		echo "<td><b>Event Name</b></td>";
		echo "<td><b>Participation Fee</b></td>";
		echo "<td><b>Event Date</b></td>";
		echo "<td><b>Version</b></td>";
  		echo "</tr>";
		while($list = mysqli_fetch_array($Nm7)){
			$participation_id=$list['participation_id'];
			$employee_name=$list['employee_name'];
			$employee_mail=$list['employee_mail'];
			$event_id=$list['event_id'];
			$event_name=$list['event_name'];
			$participation_fee=$list['participation_fee'];
			$event_date=$list['event_date'];
			$version=$list['version'];
		
			echo "<tr>";
			echo "<td>$participation_id</td>";
			echo "<td>$employee_name</td>";
			echo "<td>$employee_mail</td>";
			echo "<td>$event_id</td>";
			echo "<td>$event_name</td>";
			echo "<td><div style=\"float:right;\">$participation_fee</div></td>";
			echo "<td>";
			if ($version < '1.0.17+60') {
				$tz = new DateTimeZone('Europe/Berlin');
				$date = new DateTime($event_date);
				$date->setTimezone($tz);
				echo $date->format('Y-m-d H:i:s')." (Berlin)";
			} else if ($version > '1.0.17+60'){
				$tz = new DateTimeZone('UTC');
				$date = new DateTime($event_date);
				$date->setTimezone($tz);
				echo $event_date." (Berlin)"." / ".$date->format('Y-m-d H:i:s')." (UTC)";
			} else {
				$tz = new DateTimeZone('Asia/Jakarta');
				$date = new DateTime($event_date);
				$date->setTimezone($tz);
				echo $date->format('Y-m-d H:i:s')." (Jakarta)";
			}
			echo "</td>";
			echo "<td>$version</td>";
			echo "</tr>";
		}
			$totCase7 = "SELECT ROUND(SUM(participation_fee),2) AS total FROM participation WHERE employee_name LIKE '%$empName%' AND event_name LIKE '%$evName%' AND event_date LIKE '%$evDate%'";
			$totNmCase7 = mysqli_query($connect, $totCase7);
			$row = mysqli_fetch_array($totNmCase7);
			$sum = $row['total'];			
			echo "<tr>";
			echo "<td colspan=5>Total Fee</td>";
			echo "<td><div style=\"float:right;\">$sum</div></td>";
			echo "<td>&nbsp;</td>";
			echo "<td>&nbsp;</td>";
			echo "</tr>";
			echo "</table>";
	}
			
}
echo "<br><br><center><a href=list_data.php><input type=submit name=back value=Back></center></a>";
?>
    </div>
</body>
  
</html>