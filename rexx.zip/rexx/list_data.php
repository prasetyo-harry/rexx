<!DOCTYPE html>
<html>
  
<head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  
    <style>
		ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover:not(.active) {
  background-color: #111;
}

        .box {
            width: 100%;
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-top: 20px;
        }
    </style>
</head>
  
<body>
<?php include('rexx.php'); ?>
    <div class="container box">
    <h4>Courses Data</h4>
	<?php include('search.php'); ?>
	<div>&nbsp;</div>
    <table border="1" cellpadding="2" width="100%">
        <tr height="32">
            <td><center>Participation ID</center></td>
            <td><center>Employee Name</center></td>
            <td><center>Employee Mail</center></td>
            <td><center>Event ID</center></td>
            <td><center>Event Name</center></td>
            <td><center>Participation Fee</center></td>
            <td><center>Event Date</center></td>
            <td><center>Version</center></td>			
        </tr>
            <?php
                include('connection.php');
                $p	= 10; 
                $page		= isset($_GET["p"]) ? (int)$_GET["p"] : 1;
                $starts		= ($page>1) ? ($page * $p) - $p : 0;
                $result		= mysqli_query($connect, "SELECT * FROM participation");
                $total		= mysqli_num_rows($result);
                $pages		= ceil($total/$p);
                $shows		= mysqli_query($connect, "SELECT * FROM participation LIMIT $starts, $p");
                $no			= $starts+1;
                while($res 	= mysqli_fetch_array($shows)){
					$version = $res['version'];
            ?>
        <tr>
            <td><center><?php echo $res['participation_id']?></center></td>
            <td><div style="margin-left:4px;"><?php echo $res['employee_name']?></div></td>
            <td><div style="margin-left:4px;"><?php echo $res['employee_mail']?></div></td>
            <td><center><?php echo $res['event_id']?></td>
            <td><div style="margin-left:4px;"><?php echo $res['event_name']?></center></div></td>
            <td><div style="float:right;margin-right:4px;"><?php echo $res['participation_fee'] ?></div></td>
            <td>
				<div style="margin-left:4px;">
				<?php 
					$event_date = $res['event_date'];
					if ($version < '1.0.17+60') {
						$tz = new DateTimeZone('Europe/Berlin');
						$date = new DateTime($event_date);
						$date->setTimezone($tz);
						echo $date->format('Y-m-d H:i:s')." (Berlin)";
					} else if ($version > '1.0.17+60'){
						$tz = new DateTimeZone('UTC');
						$date = new DateTime($event_date);
						$date->setTimezone($tz);
						echo $date->format('Y-m-d H:i:s')." (UTC)";
					} else {
						$tz = new DateTimeZone('Asia/Jakarta');
						$date = new DateTime($event_date);
						$date->setTimezone($tz);
						echo $date->format('Y-m-d H:i:s')." (Jakarta)";
					}
				?>
				</div>
			</td>
            <td><div style="margin-left:4px;"><?php echo $version; ?></div></td>
        </tr>
            <?php  
                }
            ?>
    </table>
    <br />
    <div style="font-weight:bold;">
        Page :
        <?php
            for ($i=1; $i<=$pages ; $i++){
        ?>
            <a href="list_data.php?p=<?php echo $i; ?>" style="text-decoration:none">   <u><?php echo $i; ?></u></a>
        <?php
            }
        ?>
    </div>
</body>
</html>